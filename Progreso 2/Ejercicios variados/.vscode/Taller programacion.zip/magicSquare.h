#ifndef MAGICSQUARE_H
#define MAGICSQUARE_H

int cuadradoMagico(int filas, int columnas, int cuadrado[filas][columnas]);
int calcularConstanteMagica(int filas, int columnas, int cuadrado[filas][columnas]);
void imprimirCuadrado(int filas, int columnas, int cuadrado[filas][columnas]);

#endif
