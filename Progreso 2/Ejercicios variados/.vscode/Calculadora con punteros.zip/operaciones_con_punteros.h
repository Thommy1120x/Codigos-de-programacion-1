int menu (int opc);

void suma(float* a, float* b, float* r);

void resta(float* a, float* b, float* r);

void multiplicacion(float* a, float* b, float* r);

void division(float* a, float* b, float* r);

void sumaarregloescalar (float* arreglo, int tamano,  float escalar);

void comparacion(float*arreglo2, float* arreglo3 , int t);