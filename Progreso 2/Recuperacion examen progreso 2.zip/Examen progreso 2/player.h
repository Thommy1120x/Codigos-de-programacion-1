void inicio();
int ganar(int x, int y);
int movimiento_jugador(char movimiento);
void jugador();
void Movimientos_total();
void verificar_movimiento();