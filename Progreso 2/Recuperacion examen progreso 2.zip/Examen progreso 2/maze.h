void laberinto(int x, int y);
int valida_movimiento(int x, int y);